DefaultData = {
    COOKIE_NAME : "his_chat",
    USER : {
        SERVER : '12:11 AM',
        PAKINSRI : "Pakinsri",
        TNEUENGCH : "tnuengch",
        CLIENT : 'You'
    },
    ANSWER_PATH : "./asset/meta/chat.json",
    COOKIE_TIME : 'time',
}